/**
 * @file
 * demo behaviors.
 */


(function (Drupal) {

    'use strict';
  
    Drupal.behaviors.splideSlider = {
      attach (context, settings) {
  
        document.addEventListener('DOMContentLoaded', function () {
            new Splide('.splide').mount();
            // Select all speaker cards outside the popup
            const speakerCards = document.querySelectorAll('.speakers-card-wrapper .speaker-card');
            console.log("card clicked");

            // Hide all speaker cards inside the popup first
            const allPopups = document.querySelectorAll('.speakers-popup .speaker-card');
            allPopups.forEach(function (popup) {
              popup.style.display = 'none';
            });

            // Add click event listener to each speaker card
            speakerCards.forEach(function (card) {
                card.addEventListener('click', function () {
                    console.log("card clicked inside");
                  // Get the class name with the number (e.g., 'speaker-card-1')
                  const cardClass = Array.from(card.classList).find(cls => cls.startsWith('speaker-card-'));
                  if (cardClass) {
                    // Extract the number from the class (e.g., 'speaker-card-1' -> '1')
                    const speakerNumber = cardClass.split('-').pop();

                     // Hide all speaker cards inside the popup first
                    const hidePopups = document.querySelectorAll('.speakers-popup .speaker-card');
                      hidePopups.forEach(function (popup) {
                      popup.style.display = 'none';
                    });
                    
                    // Show the corresponding speaker card inside the popup
                    const popupToShow = document.querySelector(`.speakers-popup .speaker-detail-${speakerNumber}`);
                    if (popupToShow) {
                      popupToShow.style.display = 'flex';
                      popupToShow.style.position = 'relative';
                    }
                  }
                });
            });

            // Close popup on clicking close-btn
          const closeBtns = document.querySelectorAll('.speakers-popup .close-btn');
          closeBtns.forEach(function (btn) {
            btn.addEventListener('click', function () {
              allPopups.forEach(function (popup) {
                popup.style.display = 'none'; // Hide all popups on close
              });
            });
          });
        });
      }
    };
  
  } (Drupal));
