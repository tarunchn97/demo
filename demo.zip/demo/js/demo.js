/**
 * @file
 * demo behaviors.
 */
(function (Drupal) {

  'use strict';

  Drupal.behaviors.demo = {
    attach (context, settings) {

      console.log('It works!');

      $('.splide', context).once('splideSlider').each(function () {
        new Splide(this).mount();
      });

    }
  };

} (Drupal));
