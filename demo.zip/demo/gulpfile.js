'use strict';

// gulpfile.js
const gulp = require('gulp');
const sass = require('gulp-sass')(require('sass'));
const sassLint = require('gulp-sass-lint');

gulp.task('scss', () => {
  return gulp.src('components/**/*.scss')
    .pipe(sass().on('error', sass.logError))
    .pipe(gulp.dest((file) => {
        return file.base;
    }));
});

gulp.task('lint', function () {
    return gulp.src('components/**/*.s+(a|c)ss')
    .pipe(sassLint())
    .pipe(sassLint.format())
    .pipe(sassLint.failOnError())
});

gulp.task('watch', () => {
  gulp.watch('components/**/*.scss', gulp.series('scss','lint'));
});

gulp.task('default', gulp.series('scss','lint'));
